if (typeof module !== 'undefined' && typeof exports !== 'undefined' && module.exports === exports) {
  module.exports = 'pouchdb';
}

(function(window, angular, undefined) {
