# Hello! 👋

Do you find angular-pouchdb useful?

Unfortunately, I have little time to maintain it at the moment and would love
some help.

This library provides a thin wrapper over PouchDB for use with Angular v1.x. If
you're using Angular v2.x, it's likely that you no longer need angular-pouchdb
and can use PouchDB directly (see #94).

If you think you've found an issue, please try to isolate the problem; it maybe
that your issue may be better directed to the [PouchDB issue tracker][].

For general troubleshooting, posting your issue to StackOverflow maybe more
fruitful.

If you're able to isolate an issue or make improvements, a pull request is
gladly welcome.

If you're interested in helping to maintain the repo, please get in touch.

--- @tlvince

[pouchdb issue tracker]: https://github.com/pouchdb/pouchdb/issues
